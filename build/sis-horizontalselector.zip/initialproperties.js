define( [], function () {
    'use strict';
    return {
        /* showTitles: !1,
        showDetails: !1,
        props: { showLabels: !1, floatMode: "LEFT", initSelectionMode: "ONCE" } */
        selectionMode : "QUICK"
    };
} );